# SkyNet Network Stack

Stack de red con Pi-hole, Arpwatch y Nmap, diseñado para monitoreo y defensa de redes LAN.
