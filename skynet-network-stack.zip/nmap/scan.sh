#!/bin/bash
RANGO="${RANGO_RED}"
FECHA=$(date +%Y%m%d_%H%M%S)
ARCHIVO="/scan/resultados_$FECHA.txt"

echo "[+] Escaneando red: $RANGO"
nmap -sn $RANGO -oN "$ARCHIVO"
